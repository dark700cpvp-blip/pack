# FrostSMP Texture Pack

Buz temalı Minecraft ana menü texture pack'i (logo, butonlar, panorama arka planı).

## Kurulum
1. Klasörü/zip'i `.minecraft/resourcepacks` içine at
2. Oyunda **Seçenekler > Kaynak Paketleri** > FrostSMP'yi etkinleştir

## Uyumluluk
Minecraft **1.20.2 ve üstü** (buton sprite sistemi). Başka sürüm için `pack.mcmeta` içindeki `pack_format` değerini düzenle.

## Özelleştirme
- Logo: `assets/minecraft/textures/gui/title/minecraft.png`
- Butonlar: `assets/minecraft/textures/gui/sprites/widget/`
- Arka plan: `assets/minecraft/textures/gui/title/background/`
